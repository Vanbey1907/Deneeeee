import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();
  await WakelockPlus.enable();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Color(0xFF07090E),
    ),
  );
  runApp(const NovaStreamApp());
}

class NovaStreamApp extends StatelessWidget {
  const NovaStreamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NovaStream IPTV Pro',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF07090E),
        primaryColor: const Color(0xFF00F0FF),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00F0FF),
          secondary: Color(0xFF7000FF),
          surface: Color(0xFF111520),
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const MainDashboard(),
    );
  }
}

enum ContentType { live, movie, series }
enum SourceProtocol { xtream, m3u, stalker, direct }

class StreamItem {
  final String id;
  final String name;
  final String streamUrl;
  final String logo;
  final String group;
  final ContentType type;
  final Map<String, String> headers;
  final String? epgChannelId;
  final bool isAdult;

  StreamItem({
    required this.id,
    required this.name,
    required this.streamUrl,
    this.logo = '',
    this.group = 'Genel',
    this.type = ContentType.live,
    this.headers = const {'User-Agent': 'NovaStream/2.0 (Android; LibMPV)'},
    this.epgChannelId,
    this.isAdult = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'streamUrl': streamUrl,
        'logo': logo,
        'group': group,
        'type': type.index,
        'headers': headers,
        'epgChannelId': epgChannelId,
        'isAdult': isAdult,
      };

  factory StreamItem.fromJson(Map<String, dynamic> json) => StreamItem(
        id: json['id'],
        name: json['name'],
        streamUrl: json['streamUrl'],
        logo: json['logo'] ?? '',
        group: json['group'] ?? 'Genel',
        type: ContentType.values[json['type'] ?? 0],
        headers: Map<String, String>.from(json['headers'] ?? {}),
        epgChannelId: json['epgChannelId'],
        isAdult: json['isAdult'] ?? false,
      );
}

class UniversalIptvEngine {
  static Future<List<StreamItem>> parseM3U(String urlOrContent, {bool isRaw = false}) async {
    String body = urlOrContent;
    if (!isRaw) {
      final response = await http.get(Uri.parse(urlOrContent));
      if (response.statusCode != 200) {
        throw Exception('M3U indirilemedi: HTTP ${response.statusCode}');
      }
      body = utf8.decode(response.bodyBytes, allowMalformed: true);
    }

    final lines = const LineSplitter().convert(body);
    final List<StreamItem> items = [];

    String currentName = 'Bilinmeyen Kanal';
    String currentLogo = '';
    String currentGroup = 'Genel';
    String? currentEpgId;
    Map<String, String> currentHeaders = {'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20'};

    final RegExp logoRegex = RegExp(r'tvg-logo="([^"]*)"', caseSensitive: false);
    final RegExp groupRegex = RegExp(r'group-title="([^"]*)"', caseSensitive: false);
    final RegExp epgRegex = RegExp(r'tvg-id="([^"]*)"', caseSensitive: false);
    final RegExp uaRegex = RegExp(r'http-user-agent="([^"]*)"', caseSensitive: false);

    int counter = 1;
    for (String rawLine in lines) {
      final line = rawLine.trim();
      if (line.isEmpty) continue;

      if (line.startsWith('#EXTINF:')) {
        currentLogo = logoRegex.firstMatch(line)?.group(1) ?? '';
        currentGroup = groupRegex.firstMatch(line)?.group(1) ?? 'Genel';
        currentEpgId = epgRegex.firstMatch(line)?.group(1);
        final uaMatch = uaRegex.firstMatch(line)?.group(1);
        if (uaMatch != null && uaMatch.isNotEmpty) {
          currentHeaders['User-Agent'] = uaMatch;
        }
        final commaIndex = line.lastIndexOf(',');
        if (commaIndex != -1 && commaIndex + 1 < line.length) {
          currentName = line.substring(commaIndex + 1).trim();
        }
      } else if (line.startsWith('#EXTVLCOPT:http-user-agent=')) {
        currentHeaders['User-Agent'] = line.split('=')[1].trim();
      } else if (line.startsWith('#EXTVLCOPT:http-referrer=')) {
        currentHeaders['Referer'] = line.split('=')[1].trim();
      } else if (!line.startsWith('#')) {
        ContentType detectedType = ContentType.live;
        final lowerUrl = line.toLowerCase();
        if (lowerUrl.contains('/movie/') || lowerUrl.endsWith('.mp4') || lowerUrl.endsWith('.mkv')) {
          detectedType = ContentType.movie;
        } else if (lowerUrl.contains('/series/')) {
          detectedType = ContentType.series;
        }

        final isAdult = currentGroup.toLowerCase().contains('adult') ||
            currentGroup.toLowerCase().contains('+18') ||
            currentName.toLowerCase().contains('+18');

        items.add(
          StreamItem(
            id: 'm3u_${counter++}',
            name: currentName,
            streamUrl: line,
            logo: currentLogo,
            group: currentGroup.isEmpty ? 'Genel' : currentGroup,
            type: detectedType,
            headers: Map<String, String>.from(currentHeaders),
            epgChannelId: currentEpgId,
            isAdult: isAdult,
          ),
        );
        currentName = 'Kanal $counter';
        currentLogo = '';
        currentGroup = 'Genel';
        currentHeaders = {'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20'};
      }
    }
    return items;
  }

  static Future<List<StreamItem>> fetchXtreamCodes({
    required String serverUrl,
    required String username,
    required String password,
  }) async {
    String cleanBase = serverUrl.trim();
    if (cleanBase.endsWith('/')) cleanBase = cleanBase.substring(0, cleanBase.length - 1);

    final List<StreamItem> allItems = [];
    final Map<String, String> categoryMap = {};

    final catRes = await http.get(Uri.parse(
        '$cleanBase/player_api.php?username=$username&password=$password&action=get_live_categories'));
    if (catRes.statusCode == 200) {
      final List<dynamic> cats = jsonDecode(catRes.body);
      for (var c in cats) {
        categoryMap[c['category_id'].toString()] = c['category_name'].toString();
      }
    }

    final liveRes = await http.get(Uri.parse(
        '$cleanBase/player_api.php?username=$username&password=$password&action=get_live_streams'));
    if (liveRes.statusCode == 200) {
      final List<dynamic> streams = jsonDecode(liveRes.body);
      for (var s in streams) {
        final streamId = s['stream_id'].toString();
        final catId = s['category_id']?.toString() ?? '';
        final groupName = categoryMap[catId] ?? 'Canli TV';
        allItems.add(
          StreamItem(
            id: 'xc_live_$streamId',
            name: s['name'] ?? 'Kanal $streamId',
            streamUrl: '$cleanBase/live/$username/$password/$streamId.ts',
            logo: s['stream_icon'] ?? '',
            group: groupName,
            type: ContentType.live,
            epgChannelId: s['epg_channel_id']?.toString(),
          ),
        );
      }
    }

    final vodRes = await http.get(Uri.parse(
        '$cleanBase/player_api.php?username=$username&password=$password&action=get_vod_streams'));
    if (vodRes.statusCode == 200) {
      final List<dynamic> vods = jsonDecode(vodRes.body);
      for (var v in vods) {
        final streamId = v['stream_id'].toString();
        final ext = v['container_extension'] ?? 'mp4';
        allItems.add(
          StreamItem(
            id: 'xc_vod_$streamId',
            name: v['name'] ?? 'Film $streamId',
            streamUrl: '$cleanBase/movie/$username/$password/$streamId.$ext',
            logo: v['stream_icon'] ?? '',
            group: 'Sinema (VOD)',
            type: ContentType.movie,
          ),
        );
      }
    }

    return allItems;
  }

  static Future<List<StreamItem>> fetchStalkerPortal({
    required String portalUrl,
    required String macAddress,
  }) async {
    String cleanUrl = portalUrl.trim();
    if (cleanUrl.endsWith('/')) cleanUrl = cleanUrl.substring(0, cleanUrl.length - 1);

    final headers = {
      'User-Agent':
          'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
      'Cookie': 'mac=${Uri.encodeComponent(macAddress)}; stb_lang=en; timezone=Europe/Istanbul',
    };

    final handshakeUri = Uri.parse(
        '$cleanUrl/server/load.php?type=stb&action=handshake&token=&JsHttpRequest=1-xml');
    final hsResponse = await http.get(handshakeUri, headers: headers);
    if (hsResponse.statusCode != 200) {
      throw Exception('Stalker Portal Handshake basarisiz: ${hsResponse.statusCode}');
    }

    final hsJson = jsonDecode(hsResponse.body);
    final token = hsJson['js']?['token'] ?? '';
    headers['Authorization'] = 'Bearer $token';

    final chUri = Uri.parse(
        '$cleanUrl/server/load.php?type=itv&action=get_all_channels&JsHttpRequest=1-xml');
    final chResponse = await http.get(chUri, headers: headers);
    final chJson = jsonDecode(chResponse.body);
    final List<dynamic> data = chJson['js']?['data'] ?? [];

    final List<StreamItem> items = [];
    for (var ch in data) {
      String cmd = ch['cmd']?.toString() ?? '';
      if (cmd.startsWith('ffrt ')) cmd = cmd.replaceFirst('ffrt ', '').trim();
      if (cmd.startsWith('ffmpeg ')) cmd = cmd.replaceFirst('ffmpeg ', '').trim();

      items.add(
        StreamItem(
          id: 'mag_${ch['id']}',
          name: ch['name'] ?? 'MAG Kanal',
          streamUrl: cmd,
          logo: ch['logo'] ?? '',
          group: 'Stalker TV',
          type: ContentType.live,
          headers: headers,
        ),
      );
    }
    return items;
  }
}

class MainDashboard extends StatefulWidget {
  const MainDashboard({super.key});

  @override
  State<MainDashboard> createState() => _MainDashboardState();
}

class _MainDashboardState extends State<MainDashboard> {
  List<StreamItem> _allStreams = [];
  Set<String> _favorites = {};
  List<String> _watchHistory = [];
  String _selectedGroup = 'Tümü';
  ContentType _selectedTab = ContentType.live;
  String _searchQuery = '';
  bool _isLoading = false;
  bool _parentalUnlocked = false;
  final String _defaultPin = '0000';

  final List<StreamItem> _demoStreams = [
    StreamItem(
      id: 'demo_1',
      name: 'TRT World HD (Canlı Yayın)',
      streamUrl: 'https://tv-trtworld.medya.trt.com.tr/master.m3u8',
      group: 'Haber & Uluslararası',
      type: ContentType.live,
      epgChannelId: 'TRTWorld.tr',
    ),
    StreamItem(
      id: 'demo_2',
      name: 'Red Bull TV (4K Action Stream)',
      streamUrl: 'https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8',
      group: 'Spor & Ekstrem',
      type: ContentType.live,
    ),
    StreamItem(
      id: 'demo_3',
      name: 'NASA TV Public (Uzay Yayını)',
      streamUrl: 'https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8',
      group: 'Belgesel & Bilim',
      type: ContentType.live,
    ),
    StreamItem(
      id: 'demo_4',
      name: 'Big Buck Bunny (1080p VOD Sinema)',
      streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
      group: 'Sinema (VOD)',
      type: ContentType.movie,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _loadSavedData();
  }

  Future<void> _loadSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    final favList = prefs.getStringList('favorites') ?? [];
    final historyList = prefs.getStringList('watch_history') ?? [];
    final savedStreamsJson = prefs.getString('saved_streams');

    setState(() {
      _favorites = favList.toSet();
      _watchHistory = historyList;
      if (savedStreamsJson != null) {
        final List<dynamic> decoded = jsonDecode(savedStreamsJson);
        _allStreams = decoded.map((e) => StreamItem.fromJson(e)).toList();
      } else {
        _allStreams = List.from(_demoStreams);
      }
    });
  }

  Future<void> _saveStreams(List<StreamItem> items) async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = jsonEncode(items.map((e) => e.toJson()).toList());
    await prefs.setString('saved_streams', encoded);
  }

  Future<void> _toggleFavorite(String id) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (_favorites.contains(id)) {
        _favorites.remove(id);
      } else {
        _favorites.add(id);
      }
    });
    await prefs.setStringList('favorites', _favorites.toList());
  }

  Future<void> _addToHistory(String id) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _watchHistory.remove(id);
      _watchHistory.insert(0, id);
      if (_watchHistory.length > 30) _watchHistory = _watchHistory.sublist(0, 30);
    });
    await prefs.setStringList('watch_history', _watchHistory);
  }

  List<String> get _groups {
    final groups = <String>{'Tümü', 'Favoriler', 'Son İzlenenler'};
    for (var s in _allStreams.where((e) => e.type == _selectedTab)) {
      if (s.isAdult && !_parentalUnlocked) continue;
      groups.add(s.group);
    }
    return groups.toList();
  }

  List<StreamItem> get _filteredStreams {
    return _allStreams.where((item) {
      if (item.type != _selectedTab) return false;
      if (item.isAdult && !_parentalUnlocked) return false;
      if (_selectedGroup == 'Favoriler' && !_favorites.contains(item.id)) return false;
      if (_selectedGroup == 'Son İzlenenler' && !_watchHistory.contains(item.id)) return false;
      if (_selectedGroup != 'Tümü' &&
          _selectedGroup != 'Favoriler' &&
          _selectedGroup != 'Son İzlenenler' &&
          item.group != _selectedGroup) {
        return false;
      }
      if (_searchQuery.isNotEmpty &&
          !item.name.toLowerCase().contains(_searchQuery.toLowerCase()) &&
          !item.group.toLowerCase().contains(_searchQuery.toLowerCase())) {
        return false;
      }
      return true;
    }).toList();
  }

  void _showParentalPinDialog() {
    final pinCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF111520),
        title: const Text('Ebeveyn Kilidi (PIN: 0000)'),
        content: TextField(
          controller: pinCtrl,
          obscureText: true,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: '4 Haneli PIN Girin',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('İptal')),
          FilledButton(
            onPressed: () {
              if (pinCtrl.text == _defaultPin) {
                setState(() => _parentalUnlocked = !_parentalUnlocked);
                Navigator.pop(ctx);
              }
            },
            child: const Text('Onayla'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filteredStreams;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _buildTopHeader(),
            _buildSearchBar(),
            _buildCategoryChips(),
            Expanded(
              child: _isLoading
                  ? const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircularProgressIndicator(color: Color(0xFF00F0FF)),
                          SizedBox(height: 16),
                          Text('Playlist, VOD & EPG Verileri Ayrıştırılıyor...'),
                        ],
                      ),
                    )
                  : filtered.isEmpty
                      ? const Center(
                          child: Text(
                            'Bu kategoride yayın bulunamadı.\nSağ üstten M3U / Xtream / Stalker MAC ekleyebilirsiniz.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white54),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          itemCount: filtered.length,
                          itemBuilder: (context, index) {
                            final item = filtered[index];
                            final isFav = _favorites.contains(item.id);
                            return _buildChannelCard(item, isFav, filtered, index);
                          },
                        ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF111520),
        indicatorColor: const Color(0xFF00F0FF).withOpacity(0.2),
        selectedIndex: _selectedTab.index,
        onDestinationSelected: (idx) {
          setState(() {
            _selectedTab = ContentType.values[idx];
            _selectedGroup = 'Tümü';
          });
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.live_tv), label: 'Canlı TV'),
          NavigationDestination(icon: Icon(Icons.movie_creation_outlined), label: 'Filmler (VOD)'),
          NavigationDestination(icon: Icon(Icons.video_library_outlined), label: 'Diziler'),
        ],
      ),
    );
  }

  Widget _buildTopHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF00F0FF), Color(0xFF7000FF)],
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 26),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'NOVASTREAM PRO',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.4,
                  ),
                ),
                Text(
                  '4K LibMPV • M3U • Xtream • Stalker MAC',
                  style: TextStyle(fontSize: 11, color: Color(0xFF00F0FF)),
                ),
              ],
            ),
          ),
          IconButton.filledTonal(
            tooltip: 'Ebeveyn Kilidi',
            icon: Icon(
              _parentalUnlocked ? Icons.lock_open : Icons.lock_outline,
              color: _parentalUnlocked ? Colors.amberAccent : Colors.white70,
            ),
            onPressed: _showParentalPinDialog,
          ),
          const SizedBox(width: 6),
          IconButton.filledTonal(
            tooltip: '4\'lü Çoklu Ekran (Multi-View)',
            icon: const Icon(Icons.grid_view_rounded, color: Color(0xFF00F0FF)),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MultiScreenPlayer(availableStreams: _allStreams),
                ),
              );
            },
          ),
          const SizedBox(width: 6),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFF00F0FF),
              foregroundColor: Colors.black,
            ),
            icon: const Icon(Icons.add_link, size: 18),
            label: const Text('Ekle', style: TextStyle(fontWeight: FontWeight.bold)),
            onPressed: _showAddSourceModal,
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: TextField(
        onChanged: (val) => setState(() => _searchQuery = val),
        decoration: InputDecoration(
          hintText: 'Kanal, film, dizi veya EPG ara...',
          prefixIcon: const Icon(Icons.search, color: Color(0xFF00F0FF)),
          filled: true,
          fillColor: const Color(0xFF111520),
          contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryChips() {
    final groups = _groups;
    return SizedBox(
      height: 46,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: groups.length,
        itemBuilder: (context, index) {
          final grp = groups[index];
          final selected = grp == _selectedGroup;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: ChoiceChip(
              label: Text(grp),
              selected: selected,
              selectedColor: const Color(0xFF00F0FF),
              labelStyle: TextStyle(
                color: selected ? Colors.black : Colors.white70,
                fontWeight: selected ? FontWeight.bold : FontWeight.normal,
              ),
              onSelected: (_) => setState(() => _selectedGroup = grp),
            ),
          );
        },
      ),
    );
  }

  Widget _buildChannelCard(StreamItem item, bool isFav, List<StreamItem> playlist, int index) {
    return Card(
      color: const Color(0xFF111520),
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: Colors.white.withOpacity(0.05)),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        leading: Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            color: Colors.black54,
            borderRadius: BorderRadius.circular(10),
          ),
          child: item.logo.isNotEmpty
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.network(
                    item.logo,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) =>
                        const Icon(Icons.tv, color: Color(0xFF00F0FF)),
                  ),
                )
              : const Icon(Icons.tv, color: Color(0xFF00F0FF)),
        ),
        title: Text(
          item.name,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
        ),
        subtitle: Row(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 4),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: const Color(0xFF7000FF).withOpacity(0.25),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                item.group,
                style: const TextStyle(fontSize: 11, color: Colors.white70),
              ),
            ),
            const SizedBox(width: 8),
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Text(
                '• 4K HW+ Hazır',
                style: TextStyle(fontSize: 11, color: Color(0xFF00F0FF)),
              ),
            ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(
                isFav ? Icons.favorite : Icons.favorite_border,
                color: isFav ? Colors.redAccent : Colors.white54,
              ),
              onPressed: () => _toggleFavorite(item.id),
            ),
            const Icon(Icons.play_circle_fill, color: Color(0xFF00F0FF), size: 32),
          ],
        ),
        onTap: () {
          _addToHistory(item.id);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProVideoPlayerScreen(
                playlist: playlist,
                initialIndex: index,
              ),
            ),
          );
        },
      ),
    );
  }

  void _showAddSourceModal() {
    SourceProtocol selectedProtocol = SourceProtocol.xtream;
    final urlCtrl = TextEditingController();
    final userCtrl = TextEditingController();
    final passCtrl = TextEditingController();
    final macCtrl = TextEditingController(text: '00:1A:79:');

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF111520),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 24,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Evrensel IPTV Kaynağı Ekle',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 14),
                    SegmentedButton<SourceProtocol>(
                      segments: const [
                        ButtonSegment(value: SourceProtocol.xtream, label: Text('Xtream')),
                        ButtonSegment(value: SourceProtocol.m3u, label: Text('M3U8')),
                        ButtonSegment(value: SourceProtocol.stalker, label: Text('Stalker MAC')),
                        ButtonSegment(value: SourceProtocol.direct, label: Text('Tek Link')),
                      ],
                      selected: {selectedProtocol},
                      onSelectionChanged: (val) {
                        setModalState(() => selectedProtocol = val.first);
                      },
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: urlCtrl,
                      decoration: InputDecoration(
                        labelText: selectedProtocol == SourceProtocol.m3u
                            ? 'M3U / M3U8 Playlist URL'
                            : selectedProtocol == SourceProtocol.stalker
                                ? 'Stalker Portal URL (örn: http://portal.com/c/)'
                                : selectedProtocol == SourceProtocol.direct
                                    ? 'Doğrudan Akış URL (RTMP, HLS, TS, MKV)'
                                    : 'Sunucu Adresi (örn: http://line.iptv.com:8080)',
                        border: const OutlineInputBorder(),
                      ),
                    ),
                    if (selectedProtocol == SourceProtocol.xtream) ...[
                      const SizedBox(height: 12),
                      TextField(
                        controller: userCtrl,
                        decoration: const InputDecoration(
                          labelText: 'Kullanıcı Adı (Username)',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: passCtrl,
                        obscureText: true,
                        decoration: const InputDecoration(
                          labelText: 'Şifre (Password)',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ],
                    if (selectedProtocol == SourceProtocol.stalker) ...[
                      const SizedBox(height: 12),
                      TextField(
                        controller: macCtrl,
                        decoration: const InputDecoration(
                          labelText: 'MAG MAC Adresi (00:1A:79:XX:XX:XX)',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ],
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: FilledButton(
                        style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFF00F0FF),
                          foregroundColor: Colors.black,
                        ),
                        onPressed: () async {
                          Navigator.pop(ctx);
                          setState(() => _isLoading = true);
                          try {
                            List<StreamItem> fetched = [];
                            if (selectedProtocol == SourceProtocol.m3u) {
                              fetched = await UniversalIptvEngine.parseM3U(urlCtrl.text.trim());
                            } else if (selectedProtocol == SourceProtocol.xtream) {
                              fetched = await UniversalIptvEngine.fetchXtreamCodes(
                                serverUrl: urlCtrl.text.trim(),
                                username: userCtrl.text.trim(),
                                password: passCtrl.text.trim(),
                              );
                            } else if (selectedProtocol == SourceProtocol.stalker) {
                              fetched = await UniversalIptvEngine.fetchStalkerPortal(
                                portalUrl: urlCtrl.text.trim(),
                                macAddress: macCtrl.text.trim(),
                              );
                            } else if (selectedProtocol == SourceProtocol.direct) {
                              fetched = [
                                StreamItem(
                                  id: 'direct_${DateTime.now().millisecondsSinceEpoch}',
                                  name: 'Özel Yayın Akışı',
                                  streamUrl: urlCtrl.text.trim(),
                                  group: 'Özel Akışlar',
                                )
                              ];
                            }

                            if (fetched.isNotEmpty) {
                              setState(() {
                                _allStreams = [..._allStreams, ...fetched];
                              });
                              await _saveStreams(_allStreams);
                            }
                          } catch (e) {
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Bağlantı Hatası: $e')),
                              );
                            }
                          } finally {
                            if (mounted) setState(() => _isLoading = false);
                          }
                        },
                        child: const Text(
                          'Kanalları ve VOD İçeriklerini İçe Aktar',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class ProVideoPlayerScreen extends StatefulWidget {
  final List<StreamItem> playlist;
  final int initialIndex;

  const ProVideoPlayerScreen({
    super.key,
    required this.playlist,
    required this.initialIndex,
  });

  @override
  State<ProVideoPlayerScreen> createState() => _ProVideoPlayerScreenState();
}

class _ProVideoPlayerScreenState extends State<ProVideoPlayerScreen> {
  late final Player _player;
  late final VideoController _controller;
  late int _currentIndex;
  bool _showOverlay = true;
  bool _isLocked = false;
  double _playbackSpeed = 1.0;
  BoxFit _videoFit = BoxFit.contain;
  Timer? _sleepTimer;
  int? _sleepMinutesLeft;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _player = Player(
      configuration: const PlayerConfiguration(
        bufferSize: 64 * 1024 * 1024,
      ),
    );
    _controller = VideoController(_player);
    _loadCurrentChannel();

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  Future<void> _loadCurrentChannel() async {
    final item = widget.playlist[_currentIndex];
    await _player.open(
      Media(item.streamUrl, httpHeaders: item.headers),
      play: true,
    );
  }

  void _zapChannel(int delta) {
    setState(() {
      _currentIndex = (_currentIndex + delta) % widget.playlist.length;
      if (_currentIndex < 0) _currentIndex = widget.playlist.length - 1;
    });
    _loadCurrentChannel();
  }

  void _setSleepTimer(int minutes) {
    _sleepTimer?.cancel();
    setState(() => _sleepMinutesLeft = minutes);
    _sleepTimer = Timer.periodic(const Duration(minutes: 1), (timer) {
      if (!mounted) return;
      setState(() {
        if (_sleepMinutesLeft != null && _sleepMinutesLeft! > 1) {
          _sleepMinutesLeft = _sleepMinutesLeft! - 1;
        } else {
          _player.pause();
          timer.cancel();
          Navigator.pop(context);
        }
      });
    });
  }

  @override
  void dispose() {
    _sleepTimer?.cancel();
    _player.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currentChannel = widget.playlist[_currentIndex];

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: () => setState(() => _showOverlay = !_showOverlay),
        onVerticalDragEnd: (details) {
          if (_isLocked) return;
          if (details.primaryVelocity != null) {
            if (details.primaryVelocity! < -300) _zapChannel(1);
            if (details.primaryVelocity! > 300) _zapChannel(-1);
          }
        },
        child: Stack(
          children: [
            Center(
              child: Video(
                controller: _controller,
                fit: _videoFit,
                controls: NoVideoControls,
              ),
            ),
            if (_showOverlay && _isLocked)
              Positioned(
                top: 24,
                right: 24,
                child: IconButton.filled(
                  icon: const Icon(Icons.lock, color: Color(0xFF00F0FF)),
                  onPressed: () => setState(() => _isLocked = false),
                ),
              ),
            if (_showOverlay && !_isLocked) ...[
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.black87, Colors.transparent],
                    ),
                  ),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white),
                        onPressed: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              currentChannel.name,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              '${currentChannel.group} • Zapping Modu Aktif ${_sleepMinutesLeft != null ? "• Uyku: $_sleepMinutesLeft dk" : ""}',
                              style: const TextStyle(fontSize: 12, color: Color(0xFF00F0FF)),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        tooltip: 'Uyku Zamanlayıcısı (30 Dk)',
                        icon: const Icon(Icons.bedtime_outlined),
                        onPressed: () => _setSleepTimer(30),
                      ),
                      IconButton(
                        tooltip: 'Ses ve Altyazı İzleri',
                        icon: const Icon(Icons.subtitles_outlined),
                        onPressed: _showTracksDialog,
                      ),
                      IconButton(
                        tooltip: 'Ekran Oranı Değiştir',
                        icon: const Icon(Icons.aspect_ratio),
                        onPressed: () {
                          setState(() {
                            if (_videoFit == BoxFit.contain) {
                              _videoFit = BoxFit.cover;
                            } else if (_videoFit == BoxFit.cover) {
                              _videoFit = BoxFit.fill;
                            } else {
                              _videoFit = BoxFit.contain;
                            }
                          });
                        },
                      ),
                      IconButton(
                        tooltip: 'Ekranı Kilitle',
                        icon: const Icon(Icons.lock_open),
                        onPressed: () => setState(() => _isLocked = true),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 16,
                left: 24,
                right: 24,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      color: Colors.black.withOpacity(0.55),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              IconButton(
                                icon: const Icon(Icons.skip_previous_rounded, size: 32),
                                onPressed: () => _zapChannel(-1),
                              ),
                              StreamBuilder<bool>(
                                stream: _player.stream.playing,
                                builder: (context, snapshot) {
                                  final isPlaying = snapshot.data ?? true;
                                  return IconButton(
                                    icon: Icon(
                                      isPlaying
                                          ? Icons.pause_circle_filled
                                          : Icons.play_circle_filled,
                                      size: 42,
                                      color: const Color(0xFF00F0FF),
                                    ),
                                    onPressed: () => _player.playOrPause(),
                                  );
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.skip_next_rounded, size: 32),
                                onPressed: () => _zapChannel(1),
                              ),
                            ],
                          ),
                          TextButton.icon(
                            icon: const Icon(Icons.speed, color: Color(0xFF00F0FF)),
                            label: Text('${_playbackSpeed}x'),
                            onPressed: () {
                              final speeds = [0.5, 1.0, 1.25, 1.5, 2.0];
                              final nextIdx = (speeds.indexOf(_playbackSpeed) + 1) % speeds.length;
                              setState(() => _playbackSpeed = speeds[nextIdx]);
                              _player.setRate(_playbackSpeed);
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _showTracksDialog() {
    final audioTracks = _player.state.tracks.audio;
    final subTracks = _player.state.tracks.subtitle;

    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF111520),
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: ListView(
            shrinkWrap: true,
            children: [
              const Text('Ses Kanalları (Audio Tracks)',
                  style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF00F0FF))),
              ...audioTracks.map(
                (t) => ListTile(
                  title: Text(t.title ?? t.language ?? t.id),
                  onTap: () {
                    _player.setAudioTrack(t);
                    Navigator.pop(ctx);
                  },
                ),
              ),
              const Divider(),
              const Text('Altyazılar (Subtitles)',
                  style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF00F0FF))),
              ...subTracks.map(
                (s) => ListTile(
                  title: Text(s.title ?? s.language ?? s.id),
                  onTap: () {
                    _player.setSubtitleTrack(s);
                    Navigator.pop(ctx);
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class MultiScreenPlayer extends StatefulWidget {
  final List<StreamItem> availableStreams;

  const MultiScreenPlayer({super.key, required this.availableStreams});

  @override
  State<MultiScreenPlayer> createState() => _MultiScreenPlayerState();
}

class _MultiScreenPlayerState extends State<MultiScreenPlayer> {
  final List<Player> _players = List.generate(4, (_) => Player());
  late final List<VideoController> _controllers;
  final List<StreamItem?> _selectedSlots = [null, null, null, null];
  int _activeAudioSlot = 0;

  @override
  void initState() {
    super.initState();
    _controllers = _players.map((p) => VideoController(p)).toList();
    for (int i = 0; i < 4 && i < widget.availableStreams.length; i++) {
      _assignChannelToSlot(i, widget.availableStreams[i]);
    }
  }

  Future<void> _assignChannelToSlot(int slotIndex, StreamItem item) async {
    setState(() => _selectedSlots[slotIndex] = item);
    await _players[slotIndex].open(Media(item.streamUrl, httpHeaders: item.headers));
    _updateAudioFocus(_activeAudioSlot);
  }

  void _updateAudioFocus(int activeSlot) {
    setState(() => _activeAudioSlot = activeSlot);
    for (int i = 0; i < 4; i++) {
      _players[i].setVolume(i == activeSlot ? 100.0 : 0.0);
    }
  }

  @override
  void dispose() {
    for (var p in _players) {
      p.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF07090E),
        title: const Text('4\'lü Çoklu Ekran (Multi-View)', style: TextStyle(fontSize: 16)),
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(8),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
          childAspectRatio: 16 / 10,
        ),
        itemCount: 4,
        itemBuilder: (context, index) {
          final isAudioActive = _activeAudioSlot == index;
          final slotChannel = _selectedSlots[index];

          return GestureDetector(
            onTap: () => _updateAudioFocus(index),
            onLongPress: () => _pickChannelForSlot(index),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isAudioActive ? const Color(0xFF00F0FF) : Colors.white12,
                  width: isAudioActive ? 2.5 : 1,
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Stack(
                  children: [
                    slotChannel != null
                        ? Video(controller: _controllers[index], controls: NoVideoControls)
                        : Center(
                            child: TextButton.icon(
                              icon: const Icon(Icons.add_to_queue),
                              label: Text('Ekran ${index + 1}: Kanal Seç'),
                              onPressed: () => _pickChannelForSlot(index),
                            ),
                          ),
                    Positioned(
                      top: 8,
                      left: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black87,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              isAudioActive ? Icons.volume_up : Icons.volume_off,
                              size: 14,
                              color: isAudioActive ? const Color(0xFF00F0FF) : Colors.white54,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              slotChannel?.name ?? 'Boş Slot',
                              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _pickChannelForSlot(int slotIndex) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF111520),
      builder: (ctx) {
        return ListView.builder(
          itemCount: widget.availableStreams.length,
          itemBuilder: (context, i) {
            final ch = widget.availableStreams[i];
            return ListTile(
              title: Text(ch.name),
              subtitle: Text(ch.group),
              onTap: () {
                Navigator.pop(ctx);
                _assignChannelToSlot(slotIndex, ch);
              },
            );
          },
        );
      },
    );
  }
}
