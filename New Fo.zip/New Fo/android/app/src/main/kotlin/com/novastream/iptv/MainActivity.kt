package com.novastream.iptv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
